export type FAQ = {
  header: string;
  id: number;
  text: string;
};
