export type Country = {
  name: string;
  flag: string;
  percentage: number;
};
